Welcome to version 1.4.12 of VisualBoy.

What's new:

- fixed freeze loading VisualBoy 1.4.10 save game
- fixed reset problems on some CGB games
- fixed 24-bit screen capture

Common questions:

- link is not supported yet!
- GameShark doesn't work: yes it does. Read the FAQ file please
- where do I get ROMs? I don't know and I won't reply.
- and last: VisualBoy requires DirectX from Microsoft in order to run

Default keys are:

Button A - Z
Button B - X
Start    - RET
Select   - BS
Movement - arrow keys
Speed button - SPACE
Screen capture - F12

ESC toggles the menu bar.

Default accelerators (all languages):

Ctrl + O - File->Open...
Ctrl + L - File->Load...
Ctrl + S - File->Save...
Ctrl + R - File->Reset
Ctrl + P - File->Pause
Ctrl + X - File->Exit
F1       - Help->About...

Special thanks to all translators:

copernic       - French translation + initial translation effort + dialogs
                 for multiple cheats
grimlock       - Dutch translation + new functions (working on link and other
                 neat stuff)
czeslaw        - Polish translation
GdP            - German (and some Polish) translation
adamra         - Spanish translation
CyRUS          - DreamCast port and support
DesktopMap     - Norwegian translation
Dax Man o'War  - Italian translation
Nick Mitilinos - Greek translation
Seong Park     - Korean translation
Johan Jensen   - Swedish translation
Raimon Areste  - Catalan translation
Le Thanh Hung  - Vietnamese translation
Laust Palbo    - Danish translation
Ali Mark       - Arabic translation
Eric           - Chinese translation

English and Portuguese by Forgotten

Translations are being halted for the moment. I will post news when I will take
more translations.

Forgotten

Visit VisualBoy homepage: http://www.emuhq.com/vboy
